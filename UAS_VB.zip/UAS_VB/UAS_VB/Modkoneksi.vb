﻿Imports System.Data.OleDb
Module Modkoneksi
    Public Database As OleDbConnection
    Public Tabel As OleDbDataAdapter
    Public Data As DataSet
    Public Record As New BindingSource
    Public DML As New OleDbCommand
    Public DML2 As New OleDbCommand
    Public DML3 As New OleDbCommand

    Public Sub Koneksi()
        Database = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=rentmobil.accdb")
        Database.Open()
        If Database.State = ConnectionState.Closed Then Database.Open()
    End Sub

End Module
