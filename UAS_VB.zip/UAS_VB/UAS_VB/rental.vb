﻿Imports System.Data.OleDb
Public Class rental

    Private Sub cleardata()
        txtnik.Clear()
        txtnama.Clear()
        txtseluler.Clear()
        rtbalamat.Clear()
        txtnpolisi.Clear()
        txtwarna.Clear()
        txtmerk.Clear()
        txttotal.Text = ""
        txtsewa.Text = ""
        txtharga.Text = ""
    End Sub
    Private Sub autonumber()
        Try
            Call Koneksi()
            Dim autoid As String = "select * from rentaldetail order by id_rental desc"
            DML = New OleDbCommand(autoid, Database)
            Dim RD As OleDbDataReader = DML.ExecuteReader
            RD.Read()

            If Not RD.HasRows Then
                txtidrental.Text = "DR01"
            Else
                txtidrental.Text = Val(Microsoft.VisualBasic.Mid(RD.
                Item("id_rental").ToString, 3, 2)) + 1
                If Len(txtidrental.Text) = 1 Then
                    txtidrental.Text = "DR0" & txtidrental.Text & ""
                ElseIf Len(txtidrental.Text) = 2 Then
                    txtidrental.Text = "DR" & txtidrental.Text & ""
                ElseIf Len(txtidrental.Text) = 3 Then
                    txtidrental.Text = "D" & txtidrental.Text & ""
                End If
            End If
        Catch ex As Exception
            MessageBox.Show("Terjadi Kesalahan : " & ex.Message, "Pesan Peringatan",
            MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End Try
    End Sub
    Private Sub tbpenyewa()
        Dim simpan1 As String = "INSERT into penyewa VALUES ('" & txtnik.Text.ToString & "', '" & txtnama.Text & "', '" & txtseluler.Text.ToString & "', '" & rtbalamat.Text.ToString & "')"
        DML = New OleDbCommand(simpan1, Database)
        DML.ExecuteNonQuery()

    End Sub

    Private Sub tbrental()
        Dim simpan2 As String = "INSERT into rental VALUES ('" & txtnama.Text & "', '" & txtnpolisi.Text & "', '" & txtmerk.Text & "', '" & txtwarna.Text & "', '" & Format(txtmulai.Value, "dd/MM/yyyy") & "', '" & Format(txtbalik.Value, "dd/MM/yyyy") & "', '" & txtsewa.Text & "', '" & txttotal.Text & "')"
        DML2 = New OleDbCommand(simpan2, Database)
        DML2.ExecuteNonQuery()

    End Sub

    Private Sub tbrentaldetail()
        Dim simpan3 As String = "INSERT into rentaldetail VALUES ('" & txtidrental.Text & "','" & txtnik.Text.ToString & "','" & txtnama.Text & "', '" & txtseluler.Text.ToString & "', '" & rtbalamat.Text.ToString & "', '" & txtnpolisi.Text & "', '" & txtmerk.Text & "', '" & txtwarna.Text & "', '" & txtharga.Text & "', '" & Format(txtmulai.Value, "dd/MM/yyyy") & "', '" & Format(txtbalik.Value, "dd/MM/yyyy") & "', '" & txtsewa.Text & "', '" & txttotal.Text & "')"
        DML3 = New OleDbCommand(simpan3, Database)
        DML3.ExecuteNonQuery()

    End Sub

       Private Sub uptbpenyewa()
        Dim update01 As String = "UPDATE penyewa set NIK= '" & txtnik.Text.ToString & "', Nama='" & txtnama.Text & "',Noseluler='" & txtseluler.Text & "',Alamat='" & rtbalamat.Text & "' where NIK=@nik"
        DML = New OleDbCommand(update01, Database)
        DML.Parameters.Add("@nik", OleDbType.VarChar).Value = txtnik.Text
        DML.ExecuteNonQuery()
    End Sub

    Private Sub uptbrental()
        Dim update02 As String = "UPDATE  rental set Nama='" & txtnama.Text & "', Nopolisi='" & txtnpolisi.Text & "', merk='" & txtmerk.Text & "',warna='" & txtwarna.Text & "' ,mulai='" & Format(txtmulai.Value, "dd/MM/yyyy") & "', pengembalian='" & Format(txtbalik.Value, "dd/MM/yyyy") & "', sewa='" & txtsewa.Text & "',total= '" & txttotal.Text.ToString & "'where Nama= '" & txtnama.Text & "'"
        DML2 = New OleDbCommand(update02, Database)
        DML2.ExecuteNonQuery()
    End Sub

    Private Sub uptbrentaldetail()
        Dim update03 As String = "UPDATE rentaldetail set NIK='" & txtnik.Text.ToString & "',Nama='" & txtnama.Text & "',Noseluler='" & txtseluler.Text.ToString & "',Alamat='" & rtbalamat.Text.ToString & "',Nopolisi='" & txtnpolisi.Text & "',merk='" & txtmerk.Text & "',warna='" & txtwarna.Text & "',harga='" & txtharga.Text.ToString & "',mulai='" & Format(txtmulai.Value, "dd/MM/yyyy") & "',pengembalian='" & Format(txtbalik.Value, "dd/MM/yyyy") & "',sewa='" & txtsewa.Text & "',total='" & txttotal.Text.ToString & "'where id_rental= '" & txtidrental.Text & "'"
        DML3 = New OleDbCommand(update03, Database)
        DML3.ExecuteNonQuery()

    End Sub
    Private Sub deletepenyewa()
        Dim hapus As String = "Delete from  penyewa where NIK=@nik"
        DML = New OleDbCommand(hapus, Database)
        DML.Parameters.Add("@nik", OleDbType.VarChar).Value = txtnik.Text
        DML.ExecuteNonQuery()
    End Sub
    Private Sub deleterental()
        Dim hapus2 As String = "Delete from  rental where nama=@nama"
        DML2 = New OleDbCommand(hapus2, Database)
        DML2.Parameters.Add("@nama", OleDbType.VarChar).Value = txtnama.Text
        DML2.ExecuteNonQuery()
    End Sub
    Private Sub deleterentaldetail()
        Dim hapus3 As String = "Delete from  rentaldetail where id_rental=@idrental"
        DML = New OleDbCommand(hapus3, Database)
        DML.Parameters.Add("@idrental", OleDbType.VarChar).Value = txtidrental.Text
        DML.ExecuteNonQuery()
    End Sub

    Sub TampilGrid()
        Tabel = New OleDbDataAdapter("SELECT * FROM rentaldetail", Database)
        Data = New DataSet
        Data.Clear()
        Tabel.Fill(Data, "rentaldetail")
        DataGridView1.DataSource = (Data.Tables("rentaldetail"))
    End Sub

    Private Sub total()
        Dim total As Double = 0
        total = Val(txtharga.Text) * Val(txtsewa.Text)
        txttotal.Text = total

    End Sub

    Private Sub rental_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        txtwarna.Enabled = False
        txtmerk.Enabled = False
        txtharga.Enabled = False
        txttotal.Enabled = False
        Call TampilGrid()
        Call autonumber()
    End Sub


    Private Sub txtsewa_TextChanged(sender As Object, e As EventArgs) Handles txtsewa.TextChanged
        Call total()
    End Sub

    Private Sub txtidrental_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtidrental.KeyPress
        If e.KeyChar = Chr(13) Then
            Call Koneksi()
            Dim cari2 As String = "SELECT *FROM rentaldetail where id_rental = @id"
            DML = New OleDbCommand(cari2, Database)
            DML.Parameters.Add("@id", OleDbType.VarChar).Value = txtidrental.Text
            Dim RD As OleDbDataReader = DML.ExecuteReader
            RD.Read()

            If Not RD.HasRows Then
                MsgBox("Data Tidak ada, Silahkan coba lagi!")
                txtnik.Focus()
            Else
                txtnik.Text = RD("NIK").ToString()
                txtnama.Text = RD("Nama").ToString()
                txtseluler.Text = RD("Noseluler").ToString()
                rtbalamat.Text = RD("Alamat").ToString()
                txtnpolisi.Text = RD("Nopolisi").ToString()
                txtmerk.Text = RD("merk").ToString()
                txtwarna.Text = RD("Warna").ToString()
                txtharga.Text = RD("harga").ToString()
                txtmulai.Text = RD("mulai").ToString()
                txtbalik.Text = RD("pengembalian").ToString()
                txtsewa.Text = RD("sewa").ToString()
                txtnik.Focus()
            End If
        End If
    End Sub

    Private Sub txtnpolisi_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnpolisi.KeyPress
        If e.KeyChar = Chr(13) Then
            Call Koneksi()
            Dim cari As String = "SELECT *FROM mobil where Nopolisi = @npolisi"
            DML = New OleDbCommand(cari, Database)
            DML.Parameters.Add("@npolisi", OleDbType.VarChar).Value = txtnpolisi.Text
            Dim RD As OleDbDataReader = DML.ExecuteReader
            RD.Read()

            If Not RD.HasRows Then
                MsgBox("Data Tidak ada, Silahkan coba lagi!")
                txtnpolisi.Focus()
            Else
                txtnpolisi.Text = RD("Nopolisi").ToString()
                txtmerk.Text = RD("Merk").ToString()
                txtwarna.Text = RD("Warna").ToString()
                txtharga.Text = RD("harga").ToString()
                txtnpolisi.Focus()
            End If
        End If
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ListMobil.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtnama.Text = "" Or txtnik.Text = "" Or txtseluler.Text = "" Or rtbalamat.Text = "" Or txtnpolisi.Text = "" Then
            MsgBox("Silahkan Isi semua data terlebih dahulu", MsgBoxStyle.Information)
        Else
            Try
                Call Koneksi()
                Call tbpenyewa()
                Call tbrental()
                Call tbrentaldetail()
                MsgBox("Data Berhasil Di tambah", MsgBoxStyle.Information, "Sukses Input data")
                Call TampilGrid()
            Catch ex As Exception
                MsgBox("Data gagal Di tambah", MsgBoxStyle.Critical, "Error Input")
            End Try
        End If

    End Sub


    Private Sub Update1_Click(sender As Object, e As EventArgs) Handles Update1.Click
        If txtnama.Text = "" Or txtnik.Text = "" Or txtseluler.Text = "" Or rtbalamat.Text = "" Or txtnpolisi.Text = "" Then
            MsgBox("Silahkan Isi semua data terlebih dahulu", MsgBoxStyle.Information)
        Else
            Call Koneksi()
                Call uptbpenyewa()
            Call uptbrental()
            Call uptbrentaldetail()
            MsgBox("Data Berhasil Di update", MsgBoxStyle.Information, "Sukses update data")

        End If
        Call TampilGrid()
    End Sub

    Private Sub btnCetak_Click(sender As Object, e As EventArgs) Handles btnCetak.Click
        Call Koneksi()
        Dim cetaknote As String
        cetaknote = MsgBox("Apakah ingin cetak Bukti ?", vbQuestion + vbYesNo, "")

        If cetaknote = vbYes Then
            Dim note As New sewa
            notepenjualan.CrystalReportViewer1.SelectionFormula = "totext({rental.Nama})='" & txtnama.Text & "'"
            notepenjualan.CrystalReportViewer1.ReportSource = note
            notepenjualan.ShowDialog()

        Else

        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Call cleardata()
        Me.Close()
    End Sub

    Private Sub Btnclear_Click(sender As Object, e As EventArgs) Handles Btnclear.Click
        Call cleardata()
        Call autonumber()
    End Sub

    Private Sub btndelete_Click(sender As Object, e As EventArgs) Handles btndelete.Click
        Call Koneksi()
        Call deletepenyewa()
        Call deleterental()
        Call deleterentaldetail()
        MsgBox("Data Berhasil Di Hapus", MsgBoxStyle.Information, "Sukses Hapus data")
        Call TampilGrid()

    End Sub
End Class