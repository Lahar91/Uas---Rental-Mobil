﻿Public Class mdiuser
    Private Sub AboutAsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutAsToolStripMenuItem.Click
        about.ShowDialog()

    End Sub

    Private Sub InputMobilToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InputMobilToolStripMenuItem.Click
        inputmobil.ShowDialog()
    End Sub

    Private Sub RentalMobileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RentalMobileToolStripMenuItem.Click
        rental.ShowDialog()

    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()

    End Sub
End Class