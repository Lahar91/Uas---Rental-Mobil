﻿Imports System.Data.OleDb
Public Class Login

    Sub clear()
        txtuser.Clear()
        txtpass.Clear()
        txtuser.Focus()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub btnlogin_Click(sender As Object, e As EventArgs) Handles btnlogin.Click
        If txtuser.Text = "" Or txtpass.Text = "" Then
            MsgBox("Data Silahkan Isi Usernama atau Password Terlebih dahulu")
            Call clear()
        Else
            Call Koneksi()
            Dim datauser As String = "SELECT * FROM users WHERE username = '" & txtuser.Text & "' AND password = '" & txtpass.Text & "'"
            DML = New OleDbCommand(datauser, Database)
            Dim RD As OleDbDataReader = DML.ExecuteReader
            RD.Read()

            If RD.HasRows Then
                Me.Hide()
                If RD("username").ToString = "admin" Then
                    Dim note As New sewa
                    notepenjualan.CrystalReportViewer1.SelectionFormula = "totext({users.username})='" & txtuser.Text & "'"
                    notepenjualan.CrystalReportViewer1.ReportSource = note
                    FMDI.ShowDialog()
                Else
                    Dim note As New sewa
                    notepenjualan.CrystalReportViewer1.SelectionFormula = "totext({users.username})='" & txtuser.Text & "'"
                    notepenjualan.CrystalReportViewer1.ReportSource = note
                    mdiuser.ShowDialog()

                End If
            Else
                    MsgBox("Username atau password anda salah")
                Call clear()
            End If
        End If
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
