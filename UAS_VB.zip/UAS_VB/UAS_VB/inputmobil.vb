﻿Imports System.Data.OleDb

Public Class inputmobil

    Private Sub clear()
        txtnpolisi.Clear()
        txtmerk.Clear()
        txtwarna.Clear()
        txtrangka.Clear()
        txtmesin.Clear()
        txtharga.Clear()
    End Sub

    Sub TampilGrid()
        Tabel = New OleDbDataAdapter("SELECT * FROM mobil", Database)
        Data = New DataSet
        Data.Clear()
        Tabel.Fill(Data, "mobil")
        DataGridView1.DataSource = (Data.Tables("mobil"))
    End Sub
    Private Sub inputmobil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call TampilGrid()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtnpolisi.Text = "" Or txtmerk.Text = "" Or txtwarna.Text = "" Or txtrangka.Text = "" Or txtmesin.Text = "" Or txtharga.Text = "" Then
            MsgBox("Silahkan isi Semua Form")
        Else
            Call Koneksi()
        End If

        Dim simpan As String = "INSERT into mobil VALUES ('" & txtnpolisi.Text & "', '" & txtmerk.Text & "', '" & txtwarna.Text & "', '" & txtrangka.Text & "', '" & txtmesin.Text & "', '" & txtharga.Text & "')"
        DML = New OleDbCommand(simpan, Database)
        DML.ExecuteNonQuery()
        MsgBox("Input  Data Berhasil")

        Call TampilGrid()
        Call clear()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Call Koneksi()

        Dim edit As String = "UPDATE  mobil set Merk= '" & txtmerk.Text & "',Warna='" & txtwarna.Text & "',Norangka='" & txtrangka.Text & "',Nomesin='" & txtmesin.Text & "',harga='" & txtharga.Text & "' where Nopolisi=@npolisi"
        DML = New OleDbCommand(edit, Database)
        DML.Parameters.Add("@npolisi", OleDbType.VarChar).Value = txtnpolisi.Text
        DML.ExecuteNonQuery()
        MsgBox("Data Berhasil diupdate")
        Call TampilGrid()
        Call clear()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim hapus As String = "Delete from  mobil where Nopolisi=@npolisi"
        DML = New OleDbCommand(hapus, Database)
        DML.Parameters.Add("@npolisi", OleDbType.VarChar).Value = txtnpolisi.Text
        DML.ExecuteNonQuery()
        MsgBox("Data Berhasil dihapus")
        Call TampilGrid()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Me.Close()
    End Sub

    Private Sub txtnpolisi_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtnpolisi.KeyPress
        If e.KeyChar = Chr(13) Then
            Call Koneksi()
            Dim cari As String = "SELECT *FROM mobil where Nopolisi = @npolisi"
            DML = New OleDbCommand(cari, Database)
            DML.Parameters.Add("@npolisi", OleDbType.VarChar).Value = txtnpolisi.Text
            Dim RD As OleDbDataReader = DML.ExecuteReader
            RD.Read()

            If Not RD.HasRows Then
                MsgBox("Data Tidak ada, Silahkan coba lagi!")
                txtnpolisi.Focus()
            Else
                txtnpolisi.Text = RD("Nopolisi").ToString()
                txtmerk.Text = RD("Merk").ToString()
                txtwarna.Text = RD("Warna").ToString()
                txtrangka.Text = RD("Norangka").ToString()
                txtmesin.Text = RD("Nomesin").ToString()
                txtharga.Text = RD("harga").ToString()
                txtnpolisi.Focus()
            End If
        End If

    End Sub
End Class