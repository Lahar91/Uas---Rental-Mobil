﻿Public Class Laporan
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim laporan As New LaporanSewa
        Lsewa.CrystalReportViewer1.SelectionFormula = "{rental.mulai} in date ('" & Format(DateTimePicker1.Value, "dd/MM/yyyy") & "') to date ('" & Format(DateTimePicker2.Value, "dd/MM/yyyy") & "')"
        Lsewa.CrystalReportViewer1.ReportSource = laporan
        Lsewa.ShowDialog()
    End Sub

    Private Sub Laporan_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class