﻿Imports System.Data.OleDb

Public Class ListMobil
    Sub CARI()
        Call Koneksi()
        Tabel = New OleDbDataAdapter("SELECT * FROM mobil WHERE Merk LIKE '%" & txtcari.Text & "%'", Database)
        Data = New DataSet
        Tabel.Fill(Data)
        DataGridView1.DataSource = (Data.Tables(0))
    End Sub

    Private Sub TampilGrid()
        Tabel = New OleDbDataAdapter("SELECT * FROM mobil", Database)
        Data = New DataSet
        Data.Clear()
        Tabel.Fill(Data, "mobil")
        DataGridView1.DataSource = (Data.Tables("mobil"))
    End Sub

    Private Sub ListMobil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()
        Call TampilGrid()

    End Sub
    Private Sub Btncari_Click(sender As Object, e As EventArgs) Handles Btncari.Click
        If txtcari.Text = "" Then
            MsgBox("Silahkan Masukan Merk kendaran yang ingin di cari", MsgBoxStyle.Information, "Informasi")
            Call TampilGrid()
        Else
            Call Koneksi()
            Call CARI()

        End If
    End Sub

End Class