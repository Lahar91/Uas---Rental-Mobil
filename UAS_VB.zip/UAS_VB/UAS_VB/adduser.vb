﻿Imports System.Data.OleDb

Public Class adduser

    Sub clear()
        txtuser.Clear()
        txtpas.Clear()
        txtuser.Focus()
    End Sub

    Private Sub adduser_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call Koneksi()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtuser.Text = "" Or txtpas.Text = "" Then
            MsgBox("Silahkan isi Semua Form")
        Else
            Call Koneksi()
            Dim datauser As String = "SELECT * FROM users WHERE username = '" & txtuser.Text & "' AND password = '" & txtpas.Text & "'"
            DML = New OleDbCommand(datauser, Database)
            Dim RD As OleDbDataReader = DML.ExecuteReader
            RD.Read()
            If Not RD.HasRows Then
                Call Koneksi()
                Dim simpan As String = "INSERT into users VALUES ('" & txtuser.Text & "', '" & txtpas.Text & "')"
                DML = New OleDbCommand(simpan, Database)
                DML.ExecuteNonQuery()
                MsgBox("Tambah User berhasil!", MsgBoxStyle.Information, "Suskes")
                Call clear()
            Else
                MsgBox("Tidak Bisa Menambah User, Data sudah ada!!", MsgBoxStyle.Information, "Pesan Gagal")
                Call clear()
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If txtuser.Text = "" Or txtpas.Text = "" Then
            MsgBox("Data kosong, silahkan di isi terlebih dahulu!", MsgBoxStyle.Information, "error")
        Else
            Try
                Dim hapus As String = "Delete from  users where username=@user"
                DML = New OleDbCommand(hapus, Database)
                DML.Parameters.Add("@user", OleDbType.VarChar).Value = txtuser.Text
                DML.ExecuteNonQuery()
                MsgBox("Data Berhasil dihapus", MsgBoxStyle.Information, "Sukses")
                txtuser.Clear()
                txtpas.Clear()
            Catch ex As Exception
                MsgBox("Data  gagal di hapus", MsgBoxStyle.Information, "Gagal")
            End Try
        End If

    End Sub
End Class