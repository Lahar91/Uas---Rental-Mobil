﻿Public Class FMDI
    Private Sub UserToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UserToolStripMenuItem.Click
        adduser.ShowDialog()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim keluar As String

        keluar = MsgBox("Yakin Anda ingin Keluar ?", vbQuestion + vbYesNo, "Konfirmasi")
        If keluar = vbYes Then
            Me.Close()

        ElseIf keluar = vbNo Then

        End If
    End Sub
    Private Sub AboutAsToolStripMenuItem1_Click_1(sender As Object, e As EventArgs) Handles AboutAsToolStripMenuItem1.Click
        about.ShowDialog()
    End Sub

    Private Sub InputMobilToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InputMobilToolStripMenuItem.Click
        inputmobil.ShowDialog()
    End Sub

    Private Sub RentalMobilToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RentalMobilToolStripMenuItem.Click
        rental.ShowDialog()
    End Sub

    Private Sub LaporanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LaporanToolStripMenuItem.Click
        Laporan.ShowDialog()
    End Sub

    Private Sub FMDI_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class